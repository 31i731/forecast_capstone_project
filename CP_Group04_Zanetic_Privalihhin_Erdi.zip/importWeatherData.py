

from wwo_hist import retrieve_hist_data
import os

# set working directory to store output csv file(s)

os.chdir(os.getcwd())

FREQUENCY = 24 #every 24 hours
START_DATE = '09-AUG-2016'
END_DATE = '01-JUL-2019'
API_KEY = 'c64ae40aa59b4911961130344211204'
LOCATION_LIST = ['vienna']

hist_weather_data = retrieve_hist_data(API_KEY,
                                LOCATION_LIST,
                                START_DATE,
                                END_DATE,
                                FREQUENCY,
                                location_label = False,
                                export_csv = True)